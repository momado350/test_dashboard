import dash

# app = dash.Dash(__name__,
#                 suppress_callback_exceptions=True,
#                 meta_tags=[{"name": "viewport", "content": "width=device-width"}])
suppress_callback_exceptions=True,
app = dash.Dash(__name__, meta_tags=[{"name": "viewport", "content": "width=device-width"}], assets_folder ="static",
                 assets_url_path="static")
application = app.server

#server = app.server