import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

# Connect to main app.py file
from app import app
from app import application

# Connect to your app pages
import footfall, activity, items, programs

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div([
      html.Div([
        dcc.Link('Patron Activity Dashboard', href='/activity', id='activity-link'),
        dcc.Link('Footfall Dashboard', href='/footfall', id='footfall-link'),
        dcc.Link('Items Dashboard', href='/items', id='items-link'),
        dcc.Link('Programs Dashboard', href='/programs', id='programs-link'),
        
        ], className = "create_container3 nine columns", id = "title11"),

    ], id = "header1", className = "row flex-display"),

    html.Div(id='page-content', children=[])
])

# Define the style for the selected link
selected_link_style = {
    'margin-bottom': '20px',
    'padding': '25px',
    'fontWeight': 'bold',
    'color': 'white',
    'backgroundColor': 'grey'  # Change the background color to blue for the selected link
}

# Define the style for the unselected links
unselected_link_style = {
    'margin-bottom': '20px',
    'padding': '25px',
    'fontWeight': 'bold',
    'color': 'white',
}

# Callback to update the link styles based on the current page location
@app.callback(
    Output('activity-link', 'style'),
    Output('footfall-link', 'style'),
    Output('items-link', 'style'),
    Output('programs-link', 'style'),
    Input('url', 'pathname')
)

def update_link_styles(pathname):
    # Set all link styles to unselected by default
    styles = [unselected_link_style] * 4

    # Find the index of the selected link and update its style
    if pathname == '/activity':
        styles[0] = selected_link_style
    elif pathname == '/footfall':
        styles[1] = selected_link_style
    elif pathname == '/items':
        styles[2] = selected_link_style
    elif pathname == '/programs':
        styles[3] = selected_link_style

    return styles


@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/footfall':
        return footfall.layout
    if pathname == '/activity':
        return activity.layout
    if pathname == '/items':
        return items.layout
    if pathname == '/programs':
        return programs.layout
    else:
        #return "Page Error! Please select a link"
        return footfall.layout




if __name__ == '__main__':
    application.run(debug=True, port=8080)